/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
/**
 * This sample demonstrates a simple skill built with the Amazon Alexa Skills
 * nodejs skill development kit.
 * This sample supports multiple lauguages. (en-US, en-GB, de-DE).
 * The Intent Schema, Custom Slots and Sample Utterances for this skill, as well
 * as testing instructions are located at https://github.com/alexa/skill-sample-nodejs-fact
 **/

'use strict';
const Alexa = require('alexa-sdk');

//=========================================================================================================================================
//TODO: The items below this comment need your attention.
//=========================================================================================================================================

//Replace with your app ID (OPTIONAL).  You can find this value at the top of your skill's page on http://developer.amazon.com.
//Make sure to enclose your value in quotes, like this: const APP_ID = 'amzn1.ask.skill.bb4045e6-b3e8-4133-b650-72923c5980f1';
const APP_ID = undefined;

const SKILL_NAME = 'Space Facts';
const GET_FACT_MESSAGE = "Here's your fact: ";
const HELP_MESSAGE = 'You can say tell me a space fact, or, you can say exit... What can I help you with?';
const HELP_REPROMPT = 'What can I help you with?';
const STOP_MESSAGE = 'Goodbye!';

//=========================================================================================================================================
//TODO: Replace this data with your own.  You can find translations of this data at http://github.com/alexa/skill-sample-node-js-fact/data
//=========================================================================================================================================
const data = [
    'hello',
    'hiiiiii',
    'hello! how are you?',
    'hey',
    'how is your day?',
    'hey! its good to see you.',
    'hey!nice to meet you.',
    'hello!nice to meet you.',
    
];
const welcomedata=['its nice to see you in this college. hope you like this college.',
'its good to see you here!',
'welcome to aditya group of institutions!',
'i am glad to see you here!',
'wow!its my pleasure  to  speaking with you. by the way welcome to aditya group of institutions',
'i am happy that your in aditya institutions,welcome'];
const namedata=['what is your name?',
'can you say your name?',
'may i know your name?',
'your good name please',
'your sweet name please?',];
const namedata2=['i am here to say about technical hub',
'i am trained to say about technical hub',
'my job is to say about technical hub',
'my work is to explain about technical hub',
'want to  here about technical hub',
'i am well trained to say about technical hub',];
const byedata=['well! thanks for paying attention!',
               'thanks for listening hope you enjoyed',
               'bye bye, visit again',
               'bye bye, visit again and have fun',
               'i had a good time ,comeback soon',
                
              ];
//=========================================================================================================================================
//Editing anything below this line might break your skill.
//=========================================================================================================================================

const handlers = {
    'LaunchRequest': function () {
       // this.emit('GetNewFactIntent');
       //this.emit(':ask',`hi dude how are you?`);
        const hiArr = data;
        const hiIndex = Math.floor(Math.random() * hiArr.length);
        const randomFact = hiArr[hiIndex];
        const speechOutput =  randomFact;

        this.response.cardRenderer(SKILL_NAME, randomFact);
        this.response.speak(speechOutput).listen('speechOutput');
        this.emit(':responseReady');
    },
    
   /* 'GetNewFactIntent': function () {
        const factArr = data;
        const factIndex = Math.floor(Math.random() * factArr.length);
        const randomFact = factArr[factIndex];
        const speechOutput = GET_FACT_MESSAGE + randomFact;

        this.response.cardRenderer(SKILL_NAME, randomFact);
        this.response.speak(speechOutput);
        this.emit(':responseReady');
    },*/
    'UserResponseIntent':function(){
      var greetingslot=this.event.request.intent.slots.greeting.value;
      const welcomearr=welcomedata;
      const welcomeindex=Math.floor(Math.random()*welcomearr.length);
      const randomFact=welcomearr[welcomeindex];
      const speechOutput=randomFact;
      const namearr=namedata;
      const nameindex=Math.floor(Math.random()*namearr.length);
      const name=namearr[nameindex];
      const nameoutput=name;
      if(greetingslot==='hey')
      
       this.emit(':ask',` ${greetingslot}!`+ speechOutput+ ' .' + nameoutput);
       else
       this.emit(':ask',` ${greetingslot}!`+ speechOutput +' .'+ nameoutput);
    },
    'saymynameIntent':function(){
      const namearr2=namedata2;
      const nameindex2=Math.floor(Math.random()*namearr2.length);
      const name2=namearr2[nameindex2];
      const nameoutput2=name2;
      var myname=this.event.request.intent.slots.name.value;
      this.emit(':ask',`hello! ${myname}!` + nameoutput2 +'. want to here? if your willing to listen  kindly say yes! otherwise  say no!');
    },
   
    'byeIntent':function(){
       const byearr=byedata;
      const byeindex=Math.floor(Math.random()*byearr.length);
      const bye=byearr[byeindex];
      const byeoutput=bye;
      var myname=this.event.request.intent.slots.sayingbye.value;
      if(myname=== 'thanks' || 'thankyou'  || 'not necessary' || 'noneed' || 'goodbye' || 'tata' ||'no')
     
        this.emit(':ask', byeoutput); 
     
    },
     'TechnicalHubIntent':function(){
      this.emit(':ask',' the Founder and CEO of technical hub is Mr babji neelam .In technical hub we have , Iot, CyberSecurity,webdesign,mobileapp,cisco,salesforce,machine learning,datawarehousing,autocad,robotics. if you want to know the details, say for example webdesign'); 
    },
    'SayaboutTechnicalhub':function(){
        var mycourse=this.event.request.intent.slots.course.value;
       // var mycourse2=this.event.request.intent.slots.resolutionpersPerAuthority.course.value;
        if(mycourse==='iot'){
            this.emit(':ask',`the mentors  for this  courses are   Mr rajeev and  Mr sandeep, rajeev areas of expertise in  `);
        }
        if(mycourse==='cybersecurity'){
            this.emit(':ask',`the mentor  for this  course is  Mr chaitanya. he is a certified ethical hacker. `);
        }
        if(mycourse==='webdesign'){
           this.emit(':ask',`the mentor  for this  course is  Mr sudheer and, his areas of expertise in, HTML5, CSS3, PHP, Bootstrap4, MySQLi, jQuery, AJAX, Python3, Big Data Hadoop `);
        }
        if(mycourse==='mobileapp'){
            this.emit(':ask',`the mentor  for this  course is  Mr bhaskar  and , his areas of expertise in, Android, iOS. `);
        }
    },
    'SayaboutCourse':function(){
         var mycourse2=this.event.request.intent.slots.coursetwo.value;
         if(mycourse2 ==='datawarehousing'){
             this.emit(':ask',`the mentor for this course is Mr Suresh, and his area of expertise in  C, Java, Oracle, SQL Server , Informatica, Cognos, Datastage.`);
         }
         if(mycourse2 ==='auto'){
             this.emit(':ask',`the mentor for this course is  Mr saiteja, and he is also expertise in AutoCAD, CATIA, ANSYS`);
         }
         if(mycourse2==='machinelearning'){
             this.emit(':ask',`the mentor for this course is  Mr rajeev, and he is also expertise in Python, AWS, IBM Bluemix, Machine Learning, Blockchain.`,`can you say it again?`);
         }
         if(mycourse2==='networking'){
             this.emit(':ask','the mentors for this course are Mr veerababu,Mr shaifu zama, Mr veerababu expertise in System Administration, Computer Hardware, CCNA and Mr shaifu zama expertise in Redhat, CCNA, Cyber Security, Information Storage Management. ');
         }
    },
        'Unhandled':function(){
        this.emit(':tell',`sorry, i dont understand`);
    },

    
    'AMAZON.HelpIntent': function () {
        const speechOutput = HELP_MESSAGE;
        const reprompt = HELP_REPROMPT;

        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
    'AMAZON.StopIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
};

exports.handler = function (event, context, callback) {
    const alexa = Alexa.handler(event, context, callback);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};
